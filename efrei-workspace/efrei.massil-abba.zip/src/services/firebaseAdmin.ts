// Firebase Admin SDK — server-only, never imported on the client
import { getApps, initializeApp, cert, App } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";

let adminApp: App;

function getAdminApp(): App {
    if (getApps().length === 0) {
        adminApp = initializeApp({
            credential: cert({
                projectId: process.env.FIREBASE_ADMIN_PROJECT_ID,
                clientEmail: process.env.FIREBASE_ADMIN_CLIENT_EMAIL,
                privateKey: process.env.FIREBASE_ADMIN_PRIVATE_KEY?.replace(/\\n/g, "\n"),
            }),
        });
    } else {
        adminApp = getApps()[0];
    }
    return adminApp;
}

export function getAdminAuth() {
    return getAuth(getAdminApp());
}
